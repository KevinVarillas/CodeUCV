<?php
$host = 'localhost';
$db = 'crud';
$user = 'root'; // Cambia esto si tu usuario es diferente
$pass = ''; // Cambia esto si tu contraseña es diferente

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Conexión exitosa";
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
