<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Usuario</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Actualizar Usuario</h1>
    <form action="update_process.php" method="post">
        <label for="id">ID:</label>
        <input type="text" id="id" name="id" required>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Actualizar</button>
    </form>
</body>
</html>
