<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Usuario</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Eliminar Usuario</h1>
    <form action="delete_process.php" method="post">
        <label for="id">ID:</label>
        <input type="text" id="id" name="id" required>
        <button type="submit">Eliminar</button>
    </form>
</body>
</html>
