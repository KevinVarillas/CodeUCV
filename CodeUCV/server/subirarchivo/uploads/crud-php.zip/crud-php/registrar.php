<?php
include("connection.php");
$con = connection();

$id = null;
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$especialidad = $_POST['especialidad'];
$sueldo = $_POST['sueldo'];

$sql = "INSERT INTO docentes VALUES('$id','$nombre','$apellidos','$especialidad','$sueldo')";
$query = mysqli_query($con, $sql);

if($query){
    session_start();
    $_SESSION['mensaje']="Usuario agregado correctamente";
    Header("Location: index.php");
}else{

}

?>