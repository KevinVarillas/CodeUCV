
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">
    <title>Docente crud</title>
</head>

<body>
    <?php
    ?>

    <div class="users-form"> 
        <form action="registrar.php" method="POST">
            <h1>Crear usuario</h1>
            <input type="text" name="nombre" placeholder="Nombre" required>
            <input type="text" name="apellidos" placeholder="Apellidos" required>
            <input type="text" name="especialidad" placeholder="Especialidad" required>
            <input type="text" name="sueldo" placeholder="Sueldo" required>

            <input type="submit" value="Agregar docente" >
        </form>

    
            <a href="leer.php" class="users-table--view">Ver lista</a>
        

    </div>



</body>

</html>