<?php
include('connection.php');
$con = connection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];

    // Validar y sanitizar el ID
    $id = mysqli_real_escape_string($con, $id);

    // Consulta para eliminar el docente
    $sql = "DELETE FROM docentes WHERE id='$id'";
    $query = mysqli_query($con, $sql);

    if ($query) {
        Header("Location: eliminar-form.php");
    } else {
        echo "Error al eliminar el docente.";
    }
}
?>

