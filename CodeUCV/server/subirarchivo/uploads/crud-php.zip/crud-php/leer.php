<?php
include ("connection.php");
$con = connection();

$sql = "SELECT * FROM docentes";
$query = mysqli_query($con, $sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">

    <title>Document</title>
</head>
<body>
<div class="users-table">
        <h2>Docentes registrados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>Especialidad</th>
                    <th>Sueldo</th>
                    <th>Editar</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_array($query)): ?>
                    <tr>
                        <th> <?= $row['id'] ?></th>
                        <th> <?= $row['nombre'] ?></th>
                        <th> <?= $row['apellidos'] ?></th>
                        <th> <?= $row['especialidad'] ?></th>
                        <th> <?= $row['sueldo'] ?></th>

                       <th><a href="update.php?id=<?= $row['id'] ?>" class="users-table--edit">Editar</a></th>
                    </tr>
                <?php endwhile; ?>

            </tbody>


        </table>

        <a href="eliminar-form.php" class="users-table--delete">Eliminar docente</a>

        </div>


    </div>
</body>
</html>