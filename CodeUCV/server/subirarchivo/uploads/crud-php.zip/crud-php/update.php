<?php
include('connection.php');
$con = connection();
$id=$_GET['id'];
$sql="SELECT * FROM docentes WHERE id='$id'";
$query=mysqli_query($con,$sql);
$row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">
    <title>Editar usuarios</title>
</head>
<body>
    <div class="users-form">
        <form action="edit_user.php" method="POST">
            <h1>Editar docente</h1>
            <input type="hidden" name="id" value="<?=$row['id'] ?>">
            <input type="text" name="nombre" placeholder="Nombre" value="<?=$row['nombre'] ?>">
            <input type="text" name="apellidos" placeholder="Apellidos" value="<?=$row['apellidos'] ?>">
            <input type="text" name="especialidad" placeholder="Especialidad" value="<?=$row['especialidad'] ?>">
            <input type="text" name="sueldo" placeholder="Sueldo" value="<?=$row['sueldo'] ?>">
            
            <input type="submit" value="Actualizar información">
        </form>
    </div>


</body>

</html>