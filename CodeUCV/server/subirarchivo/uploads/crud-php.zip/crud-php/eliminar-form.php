
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">
    <title>Docente crud</title>
</head>

<body>
    <div class="users-form">
        <form action="delete_user.php" method="POST">
            <h1>Eliminar docente</h1>
            <input type="text" name="id" placeholder="ID del docente" required>
            <input type="submit" value="Eliminar docente" >
        </form>
        <a href="leer.php" class="users-table--view">Ver lista</a>

    </div>



</body>

</html>