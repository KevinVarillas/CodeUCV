<?php
include("connection.php");
$con = connection();

$id = $_POST["id"]; 
$nombre = $_POST['nombre']; 
$apellidos = $_POST['apellidos'];
$especialidad = $_POST['especialidad'];
$sueldo = $_POST['sueldo']; 

$sql = "UPDATE docentes SET nombre='$nombre', apellidos='$apellidos', especialidad='$especialidad', sueldo='$sueldo' WHERE id='$id'";
$query = mysqli_query($con, $sql);

if($query) {
    Header("Location: index.php");
} else {
    echo "Error al actualizar los datos del usuario.";
}
?>
