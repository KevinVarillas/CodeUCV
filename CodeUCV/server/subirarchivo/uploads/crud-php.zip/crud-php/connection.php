<?php
// Definición de la función de conexión a la base de datos
function connection(){
    // Detalles de la conexión
    $host = "localhost"; // Dirección del servidor de la base de datos
    $user = "root"; // Nombre de usuario de la base de datos
    $pass = ""; // Contraseña de la base de datos

    $bd = "instituto"; // Nombre de la base de datos que se desea conectar
    $connect = mysqli_connect($host, $user, $pass); // Conexión a la base de datos utilizando MySQLi

    mysqli_select_db($connect, $bd); // Selecciona la base de datos que se desea utilizar

    return $connect; // Retorna el objeto de conexión a la base de datos
};
?>
