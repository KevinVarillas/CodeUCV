<?php
session_start();
include 'php/conexion_be.php';

// Obtener datos del formulario
$nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
$apellido = mysqli_real_escape_string($conexion, $_POST['apellido']);
$genero = mysqli_real_escape_string($conexion, $_POST['genero']);
$direccion = mysqli_real_escape_string($conexion, $_POST['direccion']);
$telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
$ubicacion = mysqli_real_escape_string($conexion, $_POST['ubicacion']);
$fecha_nacimiento = mysqli_real_escape_string($conexion, $_POST['fecha_nacimiento']);
$correo = mysqli_real_escape_string($conexion, $_POST['correo']);

// Verificar y procesar la imagen de perfil si se envió
if (isset($_FILES['imagen_perfil']) && $_FILES['imagen_perfil']['error'] == 0) {
    $imagen_perfil_tmp = addslashes(file_get_contents($_FILES['imagen_perfil']['tmp_name']));
} else {
    $imagen_perfil_tmp = null; // Si no se envía una imagen, puedes asignar una imagen por defecto aquí
}

// Verificar y procesar la foto de portada si se envió
if (isset($_FILES['foto_portada']) && $_FILES['foto_portada']['error'] == 0) {
    $foto_portada_tmp = addslashes(file_get_contents($_FILES['foto_portada']['tmp_name']));
} else {
    $foto_portada_tmp = null; // Opcionalmente, podrías asignar una imagen por defecto aquí
}

// Insertar los datos en la base de datos
$sql_insert = "INSERT INTO usuarios (nombre, apellido, genero, direccion, telefono, ubicacion, fecha_nacimiento, correo, imagen_perfil, foto_portada) 
               VALUES ('$nombre', '$apellido', '$genero', '$direccion', '$telefono', '$ubicacion', '$fecha_nacimiento', '$correo', '$imagen_perfil_tmp', '$foto_portada_tmp')";

if (mysqli_query($conexion, $sql_insert)) {
    // Éxito al insertar
    echo json_encode(['success' => true]);
} else {
    // Error al insertar
    echo json_encode(['success' => false, 'error' => mysqli_error($conexion)]);
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>
