<?php
session_start();
include 'conexion_be.php'; // Asegúrate de tener la conexión a la base de datos incluida

$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];

$validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo' AND contrasena='$contrasena' AND activo = 1");

if(mysqli_num_rows($validar_login) > 0){
    $usuario = mysqli_fetch_assoc($validar_login);
    $_SESSION['usuario'] = $correo;
    $_SESSION['nombre_usuario'] = $usuario['nombre_usuario']; 
    $_SESSION['id'] = $usuario['id']; // Guarda también el ID del usuario en la sesión
    header("location: ../index.php");
    exit;
} else {
    echo '
        <script>
            alert("Usuario no existe o no está activo, por favor verifique los datos introducidos");
            window.location = "../iniciosesion/iniciosesion.php";
        </script>
    ';
    exit;
}
?>
