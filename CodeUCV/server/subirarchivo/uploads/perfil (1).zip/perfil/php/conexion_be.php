
<?php

$host = "localhost";
$user = "root"; 
$pass = "";
$bd = "login_registro_db"; 
$conexion = mysqli_connect($host, $user, $pass, $bd); 

?>
