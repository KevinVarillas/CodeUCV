<?php
session_start();
include 'php/conexion_be.php';

// Obtener datos del formulario
$nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
$apellido = mysqli_real_escape_string($conexion, $_POST['apellido']);
$genero = mysqli_real_escape_string($conexion, $_POST['genero']);
$direccion = mysqli_real_escape_string($conexion, $_POST['direccion']);
$telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
$ubicacion = mysqli_real_escape_string($conexion, $_POST['ubicacion']);
$fecha_nacimiento = mysqli_real_escape_string($conexion, $_POST['fecha_nacimiento']);
$correo = $_SESSION['usuario'];

// Verificar y procesar la imagen de perfil si se envió
if (isset($_FILES['imagen_perfil']) && $_FILES['imagen_perfil']['error'] == 0) {
    $imagen_perfil_tmp = addslashes(file_get_contents($_FILES['imagen_perfil']['tmp_name']));

    // Actualizar la imagen de perfil en la base de datos
    $sql_update_imagen = "UPDATE usuarios SET imagen_perfil='$imagen_perfil_tmp' WHERE correo='$correo'";
    if (mysqli_query($conexion, $sql_update_imagen)) {
        // Éxito al actualizar la imagen de perfil
        $_SESSION['nombre'] = $nombre; // Actualizar el nombre en la sesión si se modificó
        $_SESSION['apellido'] = $apellido; // Actualizar el apellido en la sesión si se modificó
        echo json_encode(['success' => true]);
    } else {
        // Error al actualizar la base de datos con la nueva imagen
        echo json_encode(['success' => false, 'error' => 'Error al actualizar la imagen de perfil en la base de datos']);
    }
} else {
    // No se subió ninguna imagen de perfil nueva, solo actualizar los otros datos
    $sql_update_datos = "UPDATE usuarios SET 
                        nombre='$nombre', 
                        apellido='$apellido', 
                        genero='$genero', 
                        direccion='$direccion', 
                        telefono='$telefono', 
                        ubicacion='$ubicacion', 
                        fecha_nacimiento='$fecha_nacimiento' 
                        WHERE correo='$correo'";

    if (mysqli_query($conexion, $sql_update_datos)) {
        $_SESSION['nombre'] = $nombre; // Actualizar el nombre en la sesión si se modificó
        $_SESSION['apellido'] = $apellido; // Actualizar el apellido en la sesión si se modificó
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conexion)]);
    }
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>
