<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: iniciosesion.php");
    exit;
}

// Incluir el archivo de conexión a la base de datos
include 'php/conexion_be.php';

// Obtener el correo del usuario desde la sesión
$correo = $_SESSION['usuario'];

// Consultar la base de datos para obtener nombre, apellido y otros datos del usuario
$sql = "SELECT nombre, apellido, genero, direccion, telefono, ubicacion, fecha_nacimiento, imagen_perfil FROM usuarios WHERE correo = '$correo'";
$resultado = mysqli_query($conexion, $sql);

if ($resultado) {
    // Obtener los datos del usuario
    $usuario = mysqli_fetch_assoc($resultado);
    $nombre = $usuario['nombre'];
    $apellido = $usuario['apellido'];
    $genero = $usuario['genero'];
    $direccion = $usuario['direccion'];
    $telefono = $usuario['telefono'];
    $ubicacion = $usuario['ubicacion'];
    $fecha_nacimiento = $usuario['fecha_nacimiento'];
    $imagen_perfil = $usuario['imagen_perfil'];
} else {
    // Manejar el error si la consulta falla (por ejemplo, redirigir o mostrar un mensaje de error)
    // En este caso, mostrar un valor predeterminado o manejar el flujo según tu lógica de aplicación
    $nombre = '';
    $apellido = '';
    $genero = '';
    $direccion = '';
    $telefono = '';
    $ubicacion = '';
    $fecha_nacimiento = '';
    $imagen_perfil = ''; // Puedes definir una imagen por defecto si es necesario
}

mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pura wevada que quieren</title>
    <link rel="stylesheet" type="text/css" href="https://necolas.github.io/normalize.css/8.0.1/normalize.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <section class="seccion-perfil-usuario">
        <div class="perfil-usuario-header">
            <div class="perfil-usuario-portada">
                <div class="perfil-usuario-avatar" id="avatar-container">
                    <?php
                    // Mostrar imagen de perfil
                    if (!empty($imagen_perfil)) {
                        echo '<img id="avatar-img" src="data:image/jpeg;base64,' . base64_encode($imagen_perfil) . '" alt="img-avatar">';
                    } else {
                        echo '<img id="avatar-img" src="http://localhost/multimedia/relleno/img-c9.png" alt="">';
                    }
                    ?>
                    <button type="button" class="boton-avatar" id="avatar-btn">
                        <i class="far fa-image"></i>
                    </button>
                    <input type="file" name="imagen_perfil" id="file-input" style="display: none;" accept="image/*">
                </div>
                <button type="button" class="boton-portada">
                    <i class="far fa-image"></i> Cambiar fondo
                </button>
            </div>
        </div>
        <div class="perfil-usuario-body">
            <div class="perfil-usuario-bio">
                <div id="nombre-container">
                    <h3 class="usuario" id="nombre-usuario"><?php echo $_SESSION['nombre_usuario']; ?></h3>
                    <p class="nombre-completo"><?php echo $nombre . ' ' . $apellido; ?></p>
                </div>
                <p class="correo"><?php echo $correo; ?></p>
            </div>
            <form id="perfil-form" method="POST" action="actualizar_perfil.php" enctype="multipart/form-data">
                <input type="hidden" name="correo" value="<?php echo $correo; ?>">
                <div class="perfil-usuario-footer">
                    <ul class="lista-datos">
                        <li><i class="icono fas fa-map-signs"></i> Nombre: <input type="text" name="nombre" class="input-dato" id="input-nombre" value="<?php echo $nombre; ?>"></li>
                        <li><i class="icono fas fa-map-signs"></i> Apellido: <input type="text" name="apellido" class="input-dato" id="input-apellido" value="<?php echo $apellido; ?>"></li>
                        <li><i class="icono fas fa-map-signs"></i> Género: <input type="text" name="genero" class="input-dato" id="input-genero" value="<?php echo $genero; ?>"></li>
                        <li><i class="icono fas fa-map-signs"></i> Dirección de usuario: <input type="text" name="direccion" class="input-direccion" id="input-direccion" value="<?php echo $direccion; ?>"></li>
                        <li><i class="icono fas fa-phone-alt"></i> Teléfono: <input type="text" name="telefono" class="input-telefono" id="input-telefono" value="<?php echo $telefono; ?>"></li>
                    </ul>
                    <ul class="lista-datos">
                        <li><i class="icono fas fa-map-marker-alt"></i> Ubicación: <input type="text" name="ubicacion" class="input-ubicacion" id="input-ubicacion" value="<?php echo $ubicacion; ?>"></li>
                        <li><i class="icono fas fa-calendar-alt"></i> Fecha de nacimiento: <input type="date" name="fecha_nacimiento" class="input-nacimiento" id="input-nacimiento" value="<?php echo $fecha_nacimiento; ?>"></li>
                    </ul>
                    <button type="submit" class="boton-registrar" id="boton-registrar">Actualizar</button>
                </div>
            </form>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>
