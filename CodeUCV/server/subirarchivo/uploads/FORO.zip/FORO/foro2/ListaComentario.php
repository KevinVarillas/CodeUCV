<?php
require_once("../foro2/db.php");

// Verificar si se recibió la categoría como parámetro
$filter = isset($_GET['categoria']) ? $_GET['categoria'] : null;

// Preparar la consulta SQL para seleccionar comentarios según la categoría (si se proporciona)
if ($filter) {
    $sql = "SELECT * FROM comentarios WHERE categoria = ? ORDER BY id ASC";
    $sql_stmt = $conexion->prepare($sql);
    $sql_stmt->bind_param("s", $filter);
    $sql_stmt->execute();
    $result = $sql_stmt->get_result();
} else {
    // Consulta para seleccionar todos los comentarios si no se proporciona una categoría
    $sql = "SELECT * FROM comentarios ORDER BY id ASC";
    $result = $conexion->query($sql);
}

$record_set = array();

// Verificar si se obtuvieron resultados de la consulta
if ($result && $result->num_rows > 0) {
    // Recorrer los resultados y almacenarlos en un array
    while($row = $result->fetch_assoc()) {
        array_push($record_set, $row);
    }
}

// Devolver los comentarios en formato JSON
echo json_encode($record_set);
?>
