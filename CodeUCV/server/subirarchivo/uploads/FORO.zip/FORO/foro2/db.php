<?php
   $conexion = mysqli_connect("localhost","root","","login_registro_db");

?>