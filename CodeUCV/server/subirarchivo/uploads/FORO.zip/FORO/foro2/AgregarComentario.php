<!-- agregarcomentario.php -->
<?php
require_once ("../foro2/db.php");
$post = isset($_POST['comment_id']) ? $_POST['comment_id'] : "";
$comentarios = isset($_POST['comentarios']) ? $_POST['comentarios'] : "";
$nombre_usuario = isset($_POST['nombre_usuario']) ? $_POST['nombre_usuario'] : "";
$categoria = isset($_POST['categoria']) ? $_POST['categoria'] : "";

$query = "INSERT INTO comentarios(respuesta, comentarios, nombre_usuario, categoria) VALUES (?, ?, ?, ?)";

$sql_stmt = $conexion->prepare($query);

$sql_stmt->bind_param("dsss", $post, $comentarios, $nombre_usuario, $categoria);

$sql_stmt->execute();
?>
