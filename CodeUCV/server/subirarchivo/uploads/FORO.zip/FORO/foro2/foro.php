<?php
error_reporting(0);
session_start();
$varsesion = isset($_SESSION['nombre_usuario']) ? $_SESSION['nombre_usuario'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foro Colaborativo</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="foro.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<nav>
    <h2>Categorías</h2>
    <div class="comment-bar">
        <div class="comment-buttons">
            <button class="categoria-btn" data-categoria="Estructura de datos">Estructura de datos</button>
            <button class="categoria-btn" data-categoria="Programación orientada a objetos">Programación orientada a objetos</button>
            <button class="categoria-btn" data-categoria="Inteligencia artificial">Inteligencia artificial</button>
            <button class="categoria-btn" data-categoria="Python">Python</button>
        </div>
    </div>
</nav>

<!-- Contenido principal -->
<main>
    <!-- Comentarios -->
    <div class="comments">
        <div class="comment-input">
            <form id="commentForm" method="POST">
                <input type="hidden" name="nombre_usuario" value="<?php echo $varsesion; ?>">
                <input type="text" name="comentarios" id="commentInput" placeholder="Escribe tu comentario...">
                <input type="hidden" name="categoria" id="categoriaInput" value="">
                <button type="submit" class="publicar-btn">Publicar</button>
            </form>
        </div>
        <!-- Comments will be dynamically added here -->
        <div id="commentSection">
            <!-- Comments will be loaded here dynamically -->
        </div>
    </div>
</main>

<script>
    $(document).ready(function() {
        // Function to load comments based on category
        function loadComments(categoria) {
            $.ajax({
                url: "ListaComentario.php",
                method: "GET",
                data: { categoria: categoria },
                dataType: "json",
                success: function(response) {
                    var commentSection = $("#commentSection");
                    commentSection.empty();
                    if (response.length > 0) {
                        $.each(response, function(index, comment) {
                            commentSection.append("<div class='comment'>" +
                                "<div class='user-info'>" +
                                "<img src='../img/joven.jpg' alt='User Image'>" +
                                "<span>" + comment.nombre_usuario + "</span>" +
                                "</div>" +
                                "<div class='comment-text'>" +
                                "<p>" + comment.comentarios + "</p>" +
                                "</div>" +
                                "<div class='comment-actions'>" +
                                "<button><i class='uil uil-heart'></i></button>" +
                                "<button><i class='uil uil-comment-dots'></i></button>" +
                                "</div>" +
                                "</div>");
                        });
                    } else {
                        commentSection.append("<p>No se encontraron comentarios en esta categoría.</p>");
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert("Error al cargar los comentarios. Por favor, inténtalo de nuevo más tarde.");
                }
            });
        }

        // Initial loading of comments
        loadComments("");

        // Event listener for category buttons
        $(".categoria-btn").click(function() {
            var categoria = $(this).data("categoria");
            $("#categoriaInput").val(categoria); // Set the selected category in the hidden input
            loadComments(categoria);
        });

        // Event listener for comment form submission
        $("#commentForm").submit(function(event) {
            event.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                url: "AgregarComentario.php",
                method: "POST",
                data: formData,
                success: function() {
                    var categoria = $("#categoriaInput").val(); // Get the selected category from the hidden input
                    loadComments(categoria);
                    $("#commentInput").val("");
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert("Error al agregar el comentario. Por favor, inténtalo de nuevo más tarde.");
                }
            });
        });
    });
</script>

</body>
</html>
