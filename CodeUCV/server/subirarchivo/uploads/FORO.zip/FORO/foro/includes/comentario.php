<?php
include "db.php";
$nombre_usuario = $conexion->real_escape_string ($_POST['nombre_usuario']);
$comentarios= $conexion->real_escape_string ($_POST['comentarios']);
include "db.php";
$nombre_usuario= mysqli_real_escape_string($conexion,$nombre_usuario);
$comentarios= mysqli_real_escape_string($conexion,$comentarios);
$resultado=mysqli_query($conexion,'INSERT INTO comentarios (nombre_usuario, comentarios) VALUES ("'.$nombre_usuario.'", "'.$comentarios.'")');
?>