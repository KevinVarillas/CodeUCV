<?php
if (isset($_POST['accion'])){ 
    switch ($_POST['accion']){
        //casos de registros
            case 'acceso_user';
            acceso_user();
            break;

            case 'insertar_user';
            insertar_user();
            break;

        }

    }

function acceso_user(){

    extract($_POST);
    require_once ("db.php");
    $nombre_usuario= $conexion->real_escape_string($_POST['nombre_usuario']);
    $contrasena= $conexion->real_escape_string($_POST['contrasena']);
    session_start();
    $_SESSION['nombre_usuario']=$nombre_usuario;//nombre_usuario
    //$_SESSION['rol_id']=$rol_id;


    $consulta="SELECT*FROM usuarios where nombre_usuario = '$nombre_usuario' and contrasena = '$contrasena'";
    $resultado=mysqli_query($conexion,$consulta);
    $filas=mysqli_fetch_array($resultado);


    if(isset($filas)){

        header('Location: ../views/comentario.php');



} else{


    echo "<script language='JavaScript'>
    alert('Usuario o Contraseña Incorrecta');
    location.assign('./php/login_usuario_be.php');
    </script>";
        session_destroy();
    }
}

function insertar_user(){

    global $conexion;
    extract($_POST);
    include "db.php";

    $consulta="INSERT INTO usuarios (nombre_usuario, correo, contrasena)
    VALUES ('$nombre_usuario', '$correo', '$contrasena' );" ;
    $resultado=mysqli_query($conexion, $consulta);


    if($resultado){
        echo "
        <script language='JavaScript'>
        alert('El registro fue realizado correctamente');
        location.assign('./php/login_usuario_be.php');
        </script>";
   } else{
         echo "<script language='JavaScript'>
         alert('');
         location.assign('./php/login_usuario_be.php');
         </script>";
}

}

?>