
document.addEventListener('DOMContentLoaded', function() {
    const publicaciones = [
        { titulo: 'Mi primer artículo', contenido: 'Este es un artículo de ejemplo.' },
        { titulo: 'Otro artículo interesante', contenido: 'Aquí va otro artículo que escribí.' }
    ];

    const publicacionesDiv = document.getElementById('publicaciones');

    publicaciones.forEach(publicacion => {
        const article = document.createElement('article');
        article.innerHTML = `<h3>${publicacion.titulo}</h3><p>${publicacion.contenido}</p>`;
        publicacionesDiv.appendChild(article);
    });
});
