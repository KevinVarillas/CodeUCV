
<?php

function connection(){
    $host = "localhost";
    $user = "root";
    $pass = "";
    $bd = "usuarios";

    // Intentar establecer la conexión
    $connect=mysqli_connect($host, $user, $pass);

    // Verificar la conexión
    if (!$connect) {
        die("Error de conexión: " . mysqli_connect_error());
    }

    // Seleccionar la base de datos
    mysqli_select_db($connect, $bd);

    // Mostrar mensaje de conexión exitosa
    echo "¡Conexión exitosa!<br>";

    return $connect;
}

?>
