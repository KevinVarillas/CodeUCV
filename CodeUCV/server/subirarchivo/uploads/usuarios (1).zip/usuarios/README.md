# CRUD con PHP y MySQL 🐘

Este es un CRUD que creé con PHP y MySQL.
Creada para el tutorial de CRUD con PHP y MySQL en mi canal de Youtube.
**Mira el video haciendo click [aquí.](https://youtu.be/sYaEoNy5OGs)** 👈

## Uso
Solo tienes que descargar el código, correr un server con XAMPP por ejemplo y crear la tabla usuarios con los campos (id, name, lastname, username, password, email).

## MySQL
Dejaré el script de MySQL usado en el video.

Sientete libre de descargar el código y modificarlo a tu antojo. Si tienes alguna duda o sugerencia, no dudes en dejar un comentario en el video. 😉

## Mis Redes Sociales
<a href="https://www.linkedin.com/in/salmeron-alvarado/"><img align="left" src="https://raw.githubusercontent.com/yushi1007/yushi1007/main/images/linkedin.svg" alt="Salmeron | LinkedIn" width="24px"/></a>
<a href="https://www.instagram.com/salmeron.daniel_/"><img align="left" src="https://raw.githubusercontent.com/yushi1007/yushi1007/main/images/instagram.svg" alt="Salmeron | Instagram" width="24px"/></a>
